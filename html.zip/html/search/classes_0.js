var searchData=
[
  ['amqp_5fqueue',['amqp_queue',['../classamqp_1_1amqp__queue.html',1,'amqp']]]
];
