var searchData=
[
  ['frame',['frame',['../classamqp_1_1frame.html',1,'amqp']]]
];
