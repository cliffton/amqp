var searchData=
[
  ['client',['client',['../classamqp_1_1client.html',1,'amqp']]]
];
