var searchData=
[
  ['logger',['logger',['../classlogger.html',1,'']]]
];
