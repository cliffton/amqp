var searchData=
[
  ['next_5fid',['next_id',['../classamqp_1_1client.html#a85389e4d1bce03081d85d4987c168f0a',1,'amqp::client::next_id()'],['../classamqp_1_1producer.html#aeba136d7cf9a4163063b7f9c0983f239',1,'amqp::producer::next_id()']]]
];
