var searchData=
[
  ['exchange',['exchange',['../classamqp_1_1exchange.html',1,'amqp']]]
];
