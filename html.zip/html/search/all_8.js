var searchData=
[
  ['log',['log',['../classlogger.html#a4f8584ee73345d1a47227153329ed328',1,'logger']]],
  ['logger',['logger',['../classlogger.html',1,'logger'],['../classlogger.html#abca31951c787aac297a16c53347ea838',1,'logger::logger()']]]
];
